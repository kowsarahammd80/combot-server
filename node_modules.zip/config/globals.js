const globals = {
    id_token: null, 
    tokenExpiration: null,
  };
  
module.exports = globals;  